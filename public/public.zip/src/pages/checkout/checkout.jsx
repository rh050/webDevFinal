//checkout page
import React, { useContext } from "react";
import { ShopContext } from "../context/shop-context";
import axios from "axios";

fetchCartItems();

